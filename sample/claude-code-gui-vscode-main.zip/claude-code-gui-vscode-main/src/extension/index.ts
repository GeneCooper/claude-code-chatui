/**
 * Extension entry point - re-exports from extension.ts
 */
export { activate, deactivate, getDiffContent, storeDiffContent } from "./extension";
